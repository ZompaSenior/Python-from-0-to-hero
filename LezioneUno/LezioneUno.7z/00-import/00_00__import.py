"""Import standard"""

import sys

print(sys.path)
