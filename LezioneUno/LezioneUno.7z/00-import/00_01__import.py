"""Import di sottomoduli.

Non consigliatissimo, come stile, toglie un po' di visibilità su origine."""

from sys import path

print(path)
