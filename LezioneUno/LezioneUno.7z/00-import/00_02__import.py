"""Import con alias

Molto usato, senza particolari controindicazioni, ma attenti a quale alias
usare."""

import sys as s

print(s.path)
