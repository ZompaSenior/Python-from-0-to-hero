"""Import 'all'

Molto sconsigliato: si spreca memoeria importando cose inutili."""

from sys import *

print(path)
