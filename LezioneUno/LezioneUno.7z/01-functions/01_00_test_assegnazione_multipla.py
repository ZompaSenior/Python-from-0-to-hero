"""Restituzione multipla da funzioni"""

def funzione_inutile():
    return 1, 2

a, b = funzione_inutile()

print(a, b)
