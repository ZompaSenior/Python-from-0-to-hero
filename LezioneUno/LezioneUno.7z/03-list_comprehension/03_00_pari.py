numeri = [1, 2, 3, 4, 56, 77, 89, 21]

pari = []

for numero in numeri:
    if(numero % 2 == 0):
        pari.append(numero)


print(pari)
