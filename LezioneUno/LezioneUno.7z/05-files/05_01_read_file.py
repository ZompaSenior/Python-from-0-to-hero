# -*- coding: cp1252 -*-

with open("file.txt") as file_testo:
    for riga in file_testo:
        print(riga)
